# Cyprus Water Filter

Source code and assets for the Homewater water filter website, exported from the current working project.

## Run locally

Requires Node.js 22.13 or newer and npm.

```sh
git clone https://github.com/MaxCon14/Cyprus-Water-Filter.git
cd Cyprus-Water-Filter
npm ci
npm run dev
```

Open the local address printed by the development server.

## Build

```sh
npm run build
npm run start
```

The project uses React, TypeScript, Tailwind CSS, Vinext, and Cloudflare tooling. The existing Sites integration and `.openai/hosting.json` are retained for compatibility with the current hosting setup. Saving this repository does not configure automatic deployments or change the hosted website.

## Project structure

- `app/` — home, product catalogue, and certificates pages, plus styles.
- `components/` — site navigation, enquiry dialogs, language controls, and shared UI.
- `lib/` — product data, translations, certificates, and business configuration.
- `public/` — product images, hero images and videos, and certificate assets.
- `scripts/` — catalogue and translation checks.

## Business configuration

Update `lib/business.ts` with the confirmed business name, WhatsApp number, and service area. The WhatsApp number is currently blank; enquiries require configuration. Review `REVIEW-NOTES.md` and `HF2-IMAGE-NOTES.md` for product and launch notes.

Dependencies, generated builds, environment files, and local caches are excluded from Git. This snapshot includes the latest local certificate and navigation changes as of 28 October 2026.
